﻿using Caliburn.Micro;
using $safeprojectname$.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModels
{
    public partial class MainViewModel : Screen
    {
        private readonly IPlatformService _platform;
        int _count = 0;
        public void OnCounterClicked()
        {
            DisplayName = $"Pressed button on {_platform.GetPlatformName()}";
            Count++;
        }
        public MainViewModel(IPlatformService platform)
        {
            DisplayName = $"Hello World";
            _platform = platform;
        }
        public int Count
        {
            get => _count;
            set => Set(ref _count, value);
        }
    }
}
