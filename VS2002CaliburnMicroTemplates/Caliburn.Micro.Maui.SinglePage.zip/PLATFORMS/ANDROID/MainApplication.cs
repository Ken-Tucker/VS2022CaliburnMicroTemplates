﻿using Android.App;
using Android.Runtime;
using Caliburn.Micro;
using $safeprojectname$.Platform;
using $safeprojectname$.Services;
using System.Reflection;

namespace $safeprojectname$;

[Application]
public class MainApplication : Caliburn.Micro.Maui.CaliburnApplication
{
    public MainApplication(IntPtr handle, JniHandleOwnership ownership)
     : base(handle, ownership)
    {
        Initialize();
    }

    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

    protected override void Configure()
    {
        $safeprojectname$.App.Container.PerRequest<IPlatformService, PlatformService>();
    }
}
