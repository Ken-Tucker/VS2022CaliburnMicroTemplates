﻿using $safeprojectname$.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Platform
{
    public class PlatformService : IPlatformService
    {
        public string GetPlatformName()
        {
            return "Android";
        }
    
    }
}
