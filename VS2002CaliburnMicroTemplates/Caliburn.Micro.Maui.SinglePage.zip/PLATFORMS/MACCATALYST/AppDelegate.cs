﻿using Caliburn.Micro;
using Foundation;
using $safeprojectname$.Platform;
using $safeprojectname$.Services;

namespace $safeprojectname$;

[Register("AppDelegate")]
public class AppDelegate : Caliburn.Micro.Maui.CaliburnApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

    protected override void Configure()
    {
        $safeprojectname$.App.Container.PerRequest<IPlatformService, PlatformService>();
    }
}
