﻿using Caliburn.Micro;
using $safeprojectname$.Platform;
using $safeprojectname$.Services;
using $safeprojectname$.ViewModels;
using $safeprojectname$.Views;
using Caliburn.Micro.Maui;
namespace $safeprojectname$;

public partial class App : Caliburn.Micro.Maui.MauiApplication
{
    public static SimpleContainer _container;
    private static readonly ILog Log = LogManager.GetLog(typeof(App));

    public static SimpleContainer Container
    {
        get
        {
            if( _container == null )
            {
                _container = new SimpleContainer();
                _container = _container.Instance(_container);
            }
            return _container;
        }
    }

    public App()
    {
        LogManager.GetLog = type => new DebugLog(type);
        InitializeComponent();

        Initialize();


        DisplayRootViewForAsync<MainViewModel>();
    }

    protected override void Configure()
    {
        //base.Configure();
        Container.PerRequest<MainViewModel>();
        Container.PerRequest<MainView>();
    }

    protected override object GetInstance(Type service, string key)
    {
        Log.Info($"$safeprojectname$ GetInstance: {service}, {key}");
        return _container.GetInstance(service, key);
    }

    protected override IEnumerable<object> GetAllInstances(Type service)
    {
        return _container.GetAllInstances(service);
    }
}
