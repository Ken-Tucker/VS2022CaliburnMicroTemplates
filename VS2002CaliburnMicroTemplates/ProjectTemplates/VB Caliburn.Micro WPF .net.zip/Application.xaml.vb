﻿Public Class Application

    ' Application-level events, such as Startup, Exit, and DispatcherUnhandledException
    ' can be handled in this file.
    Public Sub Application()
        Dim x As Int32 = 1
    End Sub
End Class
