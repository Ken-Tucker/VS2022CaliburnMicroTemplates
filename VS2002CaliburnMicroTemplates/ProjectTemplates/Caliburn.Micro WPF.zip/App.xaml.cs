﻿using System;

namespace $safeprojectname$
{
    public partial class App
    {
        public App()
        {
            InitializeComponent();
        }
    }
}
