﻿using System;

namespace $safeprojectname$.Views
{
    public sealed partial class HomeView
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}
