﻿Class Application

    ' App-level events, such as Startup, Exit, and DispatcherUnhandledException
    ' can be handled in this file.

    Public Sub New()

    End Sub
End Class
